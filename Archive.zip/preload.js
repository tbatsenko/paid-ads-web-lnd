// preload.js

window.serverRootPath = navigator.userAgent;
