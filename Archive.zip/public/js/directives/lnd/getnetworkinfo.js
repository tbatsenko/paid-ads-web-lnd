module.exports = () => ({
  restrict: 'E',
  replace: true,
  transclude: false,
  templateUrl: 'templates/partials/lnd/getnetworkinfo.html',
});
